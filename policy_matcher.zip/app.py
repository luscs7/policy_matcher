
import streamlit as st
import pandas as pd
import os
from utils import evaluate_requirements, load_keyword_map

st.set_page_config(page_title="Recomendador de Políticas Públicas", layout="wide")
st.title("Recomendador de Políticas Públicas (pesca e afins)")

DATA_PATH = os.path.join("data", "politicas_publicas.xlsx")
KW_PATH = "keyword_map.json"
SCHEMA_PATH = "profile_schema.json"

@st.cache_data
def load_data():
    df = pd.read_excel(DATA_PATH, sheet_name=0)
    df.columns = [c.strip() for c in df.columns]
    cols = ["Número","Politicas publicas","nivel","Operacionalização/Aplicação","Descrição dos direitos","Acesso","Organização interna (Subprogramas e/ou Eixos)","Link","Observações"]
    keep = [c for c in cols if c in df.columns]
    return df[keep].copy()

@st.cache_resource
def load_configs():
    import json
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)
    kw_map = load_keyword_map(KW_PATH)
    return schema, kw_map

df = load_data()
schema, kw_map = load_configs()

st.sidebar.header("Cadastro do Perfil")
profile = {}
for field, spec in schema.items():
    label = spec.get("label", field)
    t = spec.get("type", "text")
    if t == "text":
        profile[field] = st.sidebar.text_input(label)
    elif t == "number":
        profile[field] = st.sidebar.number_input(label, min_value=0.0, step=1.0, format="%.0f")
    elif t == "bool":
        profile[field] = st.sidebar.checkbox(label, value=False)
    elif t == "select":
        options = spec.get("options", [])
        profile[field] = st.sidebar.selectbox(label, options if options else [""])
    else:
        profile[field] = st.sidebar.text_input(label)

st.sidebar.write("---")
st.sidebar.caption("Dica: edite keyword_map.json para refinar as regras de elegibilidade.")

st.subheader("Resultados")
eligible_rows = []
nearly_rows = []

if "Acesso" in df.columns:
    for idx, row in df.iterrows():
        acesso = row.get("Acesso", "")
        met, missing = evaluate_requirements(str(acesso), profile, kw_map)
        if acesso and (met or missing):
            if missing:
                nearly_rows.append((idx, met, missing))
            else:
                eligible_rows.append((idx, met, missing))

st.markdown("### Políticas elegíveis para o seu perfil")
if eligible_rows:
    for idx, met, missing in eligible_rows:
        r = df.loc[idx]
        with st.expander(f"✅ {r.get('Politicas publicas','(sem título)')} — {r.get('nivel','')}"):
            st.write("**Direitos:**", r.get("Descrição dos direitos",""))
            st.write("**Acesso (atendido):**", r.get("Acesso",""))
            link = r.get("Link")
            if isinstance(link, str) and link.startswith("http"):
                st.markdown(f"[Abrir link]({link})")
else:
    st.info("Nenhuma política 100% elegível foi identificada com as regras atuais.")

st.markdown("### Políticas quase elegíveis (o que falta)")
if nearly_rows:
    for idx, met, missing in nearly_rows:
        r = df.loc[idx]
        with st.expander(f"🟡 {r.get('Politicas publicas','(sem título)')} — {r.get('nivel','')}"):
            st.write("**Direitos:**", r.get("Descrição dos direitos",""))
            st.write("**Acesso (texto original):**", r.get("Acesso",""))
            if met:
                st.write("**Requisitos atendidos (mapeados):** ", ", ".join(met))
            if missing:
                st.write("**Requisitos ausentes (mapeados):** ", ", ".join(missing))
            link = r.get("Link")
            if isinstance(link, str) and link.startswith("http"):
                st.markdown(f"[Abrir link]({link})")
else:
    st.info("Nenhuma política parcialmente elegível foi encontrada.")

with st.expander("Ver tabela completa"):
    st.dataframe(df, use_container_width=True)
