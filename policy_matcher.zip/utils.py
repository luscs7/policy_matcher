
import re, json, unicodedata
from typing import Dict, Any, List, Tuple

def norm(s: str) -> str:
    if s is None:
        return ""
    s = str(s).lower()
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^a-z0-9\s\-_/]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def load_keyword_map(path: str) -> Dict[str, Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def check_condition(user_value, cond: Dict[str, Any]) -> bool:
    t = cond.get("type")
    op = cond.get("op")
    expected = cond.get("value")
    if t == "bool":
        return bool(user_value) == bool(expected)
    if t == "number":
        try:
            user_v = float(user_value)
        except:
            return False
        if op == "<=":
            return user_v <= float(expected)
        if op == ">=":
            return user_v >= float(expected)
        if op == "==":
            return user_v == float(expected)
        return False
    if t == "select_in":
        return str(user_value) in set(expected or [])
    if t == "text":
        return norm(user_value) == norm(expected)
    return False

def evaluate_requirements(requirement_text: str, profile: Dict[str, Any], kw_map: Dict[str, Dict[str, Any]]) -> Tuple[List[str], List[str]]:
    req = norm(requirement_text)
    met, missing = [], []
    for key, cond in kw_map.items():
        if key in req:
            ok = check_condition(profile.get(cond["field"]), cond)
            label = cond.get("label", key)
            if ok:
                met.append(label)
            else:
                missing.append(label)
    return met, missing
